from django import forms
from django.db import models
from django.db.models import fields

from .models import blog_details

class Imageform(forms.ModelForm):
    class Meta:
        model=blog_details
        fields=("image","title","summary","category","content")
