from django.urls import path
from . import views
urlpatterns = [
    path('', views.sign_up, name="sign_up"),
    path('login', views.login, name="login"),
    path('profile', views.profile, name="profile"),
    path('logout', views.logout, name="logout"),
    path('draft', views.draft, name="draft"),
    path('blog', views.blog, name="blog"),
    path('doctoritem',views.doctoritem,name="doctoritem"),
    path('appoint',views.appoint,name="appoint"),
    path('calender',views.calender,name="calender"),

]