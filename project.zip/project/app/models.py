from django.db import models

class blog_details(models.Model):
    title=models.CharField(max_length=50)
    summary=models.TextField()
    content=models.TextField()
    # image=models.ImageField(upload_to='pics')
    category=models.CharField(max_length=50,default="")

class doctor_details(models.Model):
    username=models.CharField(max_length=50)
    email=models.EmailField(max_length=254)
    appoint=models.BooleanField(default=False)


class appointform(models.Model):
    name=models.CharField(max_length=50,default="name")
    speciality=models.CharField(max_length=50)
    date=models.CharField(max_length=50,default="date")
    time=models.CharField(max_length=50,default="time")
    endtime=models.CharField(max_length=50,default="end time")