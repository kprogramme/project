from django.contrib import admin
from .models import blog_details,doctor_details,appointform
# Register your models here.
admin.site.register(blog_details)
admin.site.register(doctor_details)
admin.site.register(appointform)