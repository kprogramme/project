from django import http
import datetime
from django.core.checks import messages
from django.db.models.query_utils import RegisterLookupMixin
from django.http import request
from django.shortcuts import redirect, render
from django.contrib.auth.models import User
from django.contrib import auth
from django.http import HttpResponse
import smtplib
from .models import blog_details,doctor_details,appointform
# from app.models import contact
from email.message import EmailMessage

# Create your views here.
checkuser=False
checkl=False
checku=False
checkp=False
checke=False
def sign_up(request):
    if request.method=='POST':
        firstname=request.POST['firstname']
        lastname=request.POST['lastname']
        username=request.POST['username']
        password1=request.POST['password1']
        password2=request.POST['password2']
        email=request.POST['email']
        city=request.POST['city']
        pincode=request.POST['pin']
        state=request.POST['state']
        picture=request.POST['filename']
        # user=request.POST['user']
        # user=request.POST['user']
        print(city)
        if password1==password2:
            if User.objects.filter(username=username).exists():
                checku=True
                return render(request,"sign_up.html",{'checku':checku})
            elif User.objects.filter(email=email).exists():
                checke=True
                return render(request,"sign_up.html",{'checke':checke})
            else:
                user=User.objects.create_user(first_name=firstname,last_name=lastname,username=username,password=password1,email=email)
                
                user.save();
                return render(request,"login.html")
        else:
            checkp=True
            return render(request,"sign_up.html",{'checkp':checkp})
    else:
        return render(request,"sign_up.html")

def login(request):
    if request.method=="POST":
        username=request.POST['username']
        password=request.POST['password']
        email=request.POST['email']
        doctor=request.POST['doctor']
        global a
        a=email
        # patient=request.POST['patient']

        user=auth.authenticate(username=username,password=password,email=email)
    
        if user is not None:
            auth.login(request,user)
            if doctor=='doctor':
                checkuser=True
                doctordet=doctor_details(username=username,email=email)
                doctordet.save()
                return render(request,"profile.html",{'checkuser':checkuser,'calender':True})

            elif doctor=='patient':
                return render(request,"profile.html",{'checkuser':False})
        else:
            checkl=True
            return render(request,"login.html",{"checkl":checkl})
    else:
        return render(request,"login.html") 
def profile(request):
    return render(request,"profile.html")
def logout(request):
    auth.logout(request)
    return render(request,"sign_up.html")

def draft(request):
    lis=blog_details.objects.all()
    return render(request,"draft.html",{'lis':lis})
def blog(request):
    if request.method=='POST':
        title=request.POST['title']
        summary=request.POST['summary']
        content=request.POST['content']
        # image=request.POST['image']
        category=request.POST['category']
        user=blog_details(title=title,category=category,summary=summary,content=content)
        user.save()

        return redirect("draft")
    else:
        return render(request,"blog.html")
def doctoritem(request):
    item=doctor_details.objects.all()
    return render(request,"item.html",{'item':item})
def appoint(request):
    if request.method=='POST':
        item=doctor_details.objects.all()
        name=request.POST['name']
        speciality=request.POST['speciality']
        date=request.POST['date']
        time=request.POST['time']
        a=int(time[3:])
        b=int(time[:2])
        a+=45
        if a>=60:
            a=a-60
            b+=1
        a=str(a)
        b=str(b)
        c=f"{b}:{a}"
        endtime=c
        app=appointform(name=name,speciality=speciality,date=date,time=time,endtime=endtime)
        app.save();
        # app.time=datetime.date.min+45
        for item in item:
            if app.name==item.username:
                return render(request,"patient.html",{"date":date,"name":name,"endtime":endtime,"time":time,"speciality":speciality})
                
            else:
                return render(request,"appoint.html",{'error':True})
    else:
        return render(request,"appoint.html")

def calender(request):
    appitem=appointform.objects.all()
    return render(request,"show.html",{"appitem":appitem})